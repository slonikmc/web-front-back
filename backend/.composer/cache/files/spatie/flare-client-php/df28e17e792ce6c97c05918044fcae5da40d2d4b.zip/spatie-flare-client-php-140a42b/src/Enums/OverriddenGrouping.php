<?php

namespace Spatie\FlareClient\Enums;

class OverriddenGrouping
{
    const ExceptionClass = 'exception_class';
    const ExceptionMessage = 'exception_message';
    const ExceptionMessageAndClass = 'exception_message_and_class';
}
